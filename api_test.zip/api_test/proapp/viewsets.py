from rest_framework import viewsets
from .models import employees
from .serialization import serializingemp
from rest_framework.response import Response
from rest_framework import status

class emplistset(viewsets):
    def list(self,request):
        s = employees.objects.all()
        serializer = serializingemp(s, many=True)
        return Response(serializer.data)
    def create(self,request):
        serializer = serializingemp(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def update(self,request,pk=None):
    def partial_update(self,request,pk=None):
    def destroy(self,request,pk=None):
